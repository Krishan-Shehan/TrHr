"use client"

import { AddEmployeeData } from "@/services/employee";
import { useState } from "react";
import Navbar from "../components/navBar";



export default function AddEmployee() {
    const [formdata, setFormdata] = useState({
        name: "",
        role: "",
        skills: [],
        hourRate: ""
    });

    const handleSkillChange = (skill) => {
        const updatedSkills = formdata.skills.includes(skill)
            ? formdata.skills.filter(s => s !== skill)
            : [...formdata.skills, skill];

        setFormdata({
            ...formdata,
            skills: updatedSkills
        });
    };
    async function handelEmpAdd() {
        console.log("🚀 ~ AddEmployee ~ formdata:", formdata)
        const res = await AddEmployeeData(formdata)
        console.log("🚀 ~ handelEmpAdd ~ res:", res)
    }

    return (
        <main >
            <Navbar />
            <div className="flex min-h-screen flex-col items-center justify-center gap-2 p-24 bg-b1 ">
                <div className="bg-b2 flex flex-col gap-4 p-5 rounded shadow-2xl">
                    <div className="flex flex-row gap-2 p-2">
                        <div className="flex flex-col gap-2 p-2">
                            <span className="text-o1 font-bold">Employee Name</span>
                            <input className="bg-b3 p-2 rounded" onChange={(event) => {
                                setFormdata({
                                    ...formdata,
                                    name: event.target.value,
                                });

                            }} />
                        </div>
                        <div className="flex flex-col gap-2 p-2">
                            <span className="text-o1 font-bold">Employee role</span>
                            <input className="bg-b3 p-2 rounded" onChange={(event) => {
                                setFormdata({
                                    ...formdata,
                                    role: event.target.value,
                                });

                            }} />
                        </div>

                        <div className="flex flex-col gap-2 p-2">
                            <span className="text-o1 font-bold">Employee hourRate</span>
                            <input className="bg-b3 p-2 rounded" onChange={(event) => {
                                setFormdata({
                                    ...formdata,
                                    hourRate: event.target.value,
                                });

                            }} />
                        </div>

                    </div>
                    <div className="flex flex-col gap-2 w-1/3">
                        <span className="text-o1 font-bold">Employee skills</span>
                        {["skill1", "skill2", "skill3"].map((skillName) => (
                            <label key={skillName} className="mr-2 bg-b3 p-2 rounded">
                                <input
                                    className="bg-o1 p-2 rounded"
                                    type="checkbox"
                                    value={skillName}
                                    checked={formdata.skills.includes(skillName)}
                                    onChange={() => handleSkillChange(skillName)}
                                />
                                <span className="p-4">{skillName}</span>

                            </label>
                        ))}
                    </div>


                    <button onClick={handelEmpAdd} className="bg-o1 font-bold text-b1">Add Employee</button>
                </div>
            </div>
        </main>
    );
}