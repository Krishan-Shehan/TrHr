import connectToDB from "@/database";
import employees from "@/models/employee";

import { NextResponse } from "next/server";

export async function POST(req) {
    await connectToDB();
    const extractData = await req.json();
    console.log("🚀🚀🚀🚀🚀🚀🚀🚀🚀 ~ POST ~ extractData:", extractData)


    try {
        // const data = await projects.create(extractData)
        // console.log("🚀 ~ POST ~ data:", data)

        console.log("🚀 ~ POST ~ extractData:", extractData.employees[0])
        for (let index = 0; index < extractData.employees.length; index++) {
            console.log("🚀🚀 ~ POST ~ extractData:", extractData.employees[index])
            // console.log("🚀 ~ POST ~ extractData:", extractData.skills[index].percentage)
            const hrs = (extractData.skills[index].percentage / 100) * extractData.mnhr;
            // console.log("🚀 ~ POST ~ hrs:", hrs)
            try {
                const element = extractData.employees[index];
                console.log("🚀 ~ POST ~ element:", element[0].Availability)
                const upval = element[0].Availability - hrs
                const updateLvl2Ref = await employees.updateOne({ name: extractData.employees[index][0].name }, { $set: { Availability: upval , projectCount: extractData.employees[index][0].projectCount + 1 }})
                console.log("🚀🚀🚀 ~ POST ~ updateLvl2Ref:", updateLvl2Ref)
            
            } catch (error) {
                const element = extractData.employees[index];
                console.log("🚀 ~ POST ~ element:", element.Availability)
                const upval = element.Availability - hrs
                const updateLvl2Ref = await employees.updateOne({ name: extractData.employees[index].name }, { $set: { Availability: upval , projectCount: extractData.employees[index].projectCount + 1 }})
                console.log("🚀🚀🚀🚀 ~ POST ~ updateLvl2Ref:", updateLvl2Ref)
            }
        }
        
        return NextResponse.json({
            success: true,
            message: "Created successful!",
        });
    } catch (error) {
        console.log("🚀 ~ POST ~ error:", error);
        return NextResponse.json({
            success: false,
            message: "Faild!",
        });
    }

}