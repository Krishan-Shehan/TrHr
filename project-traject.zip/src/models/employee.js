import mongoose from "mongoose";

const employeesSchema = new mongoose.Schema(
    {
        name:String,
        role: String,
        skills:Array,
        Availability:{ type: Number, default: 1200 },
        hourRate:String,
        projectCount:{ type: Number, default: 0 },
        rateting:{ type: Number, default: 0 },
    },
    { timestamps: true }
);

const employees = mongoose.models.employees || mongoose.model("employees", employeesSchema);

export default employees;